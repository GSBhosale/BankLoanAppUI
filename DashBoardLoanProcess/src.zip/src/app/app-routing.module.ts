import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './entry/home/home.component';
import { AboutUsComponent } from './templets/about-us/about-us.component';
import { ContactComponent } from './templets/contact/contact.component';
import { LocationComponent } from './templets/location/location.component';
import { EnquiryComponent } from './entry/enquiry/enquiry.component';
import { LoginComponent } from './entry/login/login.component';

const routes: Routes = [
  {path:'' ,component:HomeComponent,
  children:[
    {path:'aboutus' , component:AboutUsComponent},
    {path:'contact' , component:ContactComponent},
    {path:'location' , component:LocationComponent},
    {path:'enquiry' , component:EnquiryComponent},
    {path:'login' , component:LoginComponent}
  ]
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
